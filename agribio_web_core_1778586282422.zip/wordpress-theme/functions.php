<?php
/**
 * NABRC Theme Functions
 */

if ( ! function_exists( 'nabrc_setup' ) ) :
	function nabrc_setup() {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
		
		// Register Menus
		register_nav_menus( array(
			'primary' => __( 'Primary Menu', 'nabrc-theme' ),
		) );
	}
endif;
add_action( 'after_setup_theme', 'nabrc_setup' );

/**
 * Enqueue scripts and styles.
 */
function nabrc_scripts() {
	// In production, we'd point to the built files in the 'dist' folder
	// For this template, we assume the built files are moved to the theme root or assets folder
	
	// Enqueue the compiled CSS
	wp_enqueue_style( 'nabrc-style', get_stylesheet_uri() );
	
	// Enqueue the React App (Vite build output)
	// Note: In a real scenario, these filenames include hashes. 
	// You should use a manifest reader or fixed filenames for this.
	$dist_path = get_template_directory() . '/dist/assets/';
	if (is_dir($dist_path)) {
		$files = scandir($dist_path);
		foreach ($files as $file) {
			if (str_ends_with($file, '.js')) {
				wp_enqueue_script('nabrc-react-app', get_template_directory_uri() . '/dist/assets/' . $file, array(), null, true);
			}
			if (str_ends_with($file, '.css')) {
				wp_enqueue_style('nabrc-react-styles', get_template_directory_uri() . '/dist/assets/' . $file);
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'nabrc_scripts' );

/**
 * Custom Post Types for NABRC
 */
function nabrc_register_cpts() {
	// Research Projects
	register_post_type('research_project', array(
		'labels' => array('name' => 'Research Projects', 'singular_name' => 'Project'),
		'public' => true,
		'has_archive' => true,
		'show_in_rest' => true,
		'menu_icon' => 'dashicons-microscope',
		'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
	));

	// Services
	register_post_type('service', array(
		'labels' => array('name' => 'Services', 'singular_name' => 'Service'),
		'public' => true,
		'show_in_rest' => true,
		'menu_icon' => 'dashicons-rest-api',
		'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
	));
}
add_action('init', 'nabrc_register_cpts');