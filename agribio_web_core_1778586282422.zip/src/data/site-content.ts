import { Target, Eye, Users, ShieldCheck, Award, FlaskConical, Microscope, GraduationCap, Building, Globe, Mail, Phone, MapPin, Clock } from 'lucide-react';

export const IconMap: Record<string, any> = {
  Target,
  Eye,
  Users,
  ShieldCheck,
  Award,
  FlaskConical,
  Microscope,
  GraduationCap,
  Building,
  Globe,
  Mail,
  Phone,
  MapPin,
  Clock
};

export interface ContentData {
  images: {
    heroLab: string;
    researchDna: string;
    heroField: string;
    microscope: string;
    training: string;
    labServices: string;
    greenhouse: string;
    publications: string;
  };
  home: {
    hero: {
      title: string;
      subtitle: string;
    };
    intro: {
      title: string;
      description: string;
      features: Array<{
        icon: string;
        title: string;
        description: string;
      }>;
    };
    highlights: Array<{
      title: string;
      description: string;
      tag: string;
      imageIndex: number; // Index of image to use
    }>;
  };
  about: {
    mission: string;
    vision: string;
    objectives: string[];
    values: Array<{
      icon: string;
      title: string;
      description: string;
    }>;
  };
  research: {
    categories: string[];
    projects: Array<{
      id: number;
      title: string;
      category: string;
      description: string;
      image: string;
    }>;
  };
  services: {
    main: Array<{
      title: string;
      description: string;
      image: string;
    }>;
    specialized: Array<{
      icon: string;
      title: string;
      detail: string;
    }>;
    steps: Array<{
      title: string;
      description: string;
    }>;
  };
  news: {
    articles: Array<{
      title: string;
      excerpt: string;
      date: string;
      category: string;
      image: string;
    }>;
    events: Array<{
      title: string;
      date: string;
    }>;
  };
  publications: {
    papers: Array<{
      title: string;
      authors: string;
      date: string;
      journal: string;
    }>;
    resources: string[];
  };
  gallery: {
    albums: Array<{
      title: string;
      count: number;
      image: string;
    }>;
    recent: string[];
  };
  contact: {
    info: {
      address: string;
      phone: string;
      email: string;
    };
    hours: Array<{
      days: string;
      hours: string;
      closed?: boolean;
    }>;
  };
}

export const siteContent: ContentData = {
  images: {
    heroLab: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/hero-lab-ce9bd47c-1774609488184.webp",
    researchDna: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/research-dna-65357148-1774609488185.webp",
    heroField: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/hero-field-f97372cf-1774609488005.webp",
    microscope: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/researcher-microscope-549425fb-1774609488348.webp",
    training: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/training-center-3ccfa164-1774609493055.webp",
    labServices: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/lab-services-fa3cd518-1774609488847.webp",
    greenhouse: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/greenhouse-research-30ff5e8b-1774609487798.webp",
    publications: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=2000"
  },
  home: {
    hero: {
      title: "Innovating Agriculture through Biotechnology",
      subtitle: "The National Agricultural Biotechnology Research Center (NABRC) is dedicated to solving food security challenges through cutting-edge science and research.",
    },
    intro: {
      title: "Pioneering Sustainable Solutions",
      description: "NABRC is at the forefront of agricultural innovation. We bridge the gap between advanced biotechnology and traditional farming, ensuring a resilient future for our national food systems. Our scientists work tirelessly to solve pressing challenges such as climate change, pest resistance, and nutritional deficiencies.",
      features: [
        { icon: "Globe", title: "Global Impact", description: "Collaborating with international research bodies." },
        { icon: "ShieldCheck", title: "Sustainability", description: "Eco-friendly agricultural breakthroughs." }
      ]
    },
    highlights: [
      {
        title: "Crop Improvement",
        description: "Developing drought-resistant and nutrient-fortified crop varieties for sustainable farming.",
        tag: "Research",
        imageIndex: 0
      },
      {
        title: "Genomic Sequencing",
        description: "Mapping the genetic blueprints of indigenous crops to enhance climate resilience.",
        tag: "Biotech",
        imageIndex: 1
      },
      {
        title: "Soil Microbiome",
        description: "Studying soil microbes to reduce chemical fertilizer dependency and improve soil health.",
        tag: "Ecology",
        imageIndex: 2
      }
    ]
  },
  about: {
    mission: "Our mission is to harness the power of biotechnology to transform agriculture into a more productive, sustainable, and resilient sector. We strive to empower farmers with advanced crop varieties and biological solutions that mitigate the risks of climate change and environmental stressors.",
    vision: "To be a world-class center of excellence in agricultural biotechnology, providing innovative solutions that ensure national and global food security.",
    objectives: [
      "Develop climate-resilient crop varieties through genetic improvement.",
      "Enhance the nutritional value of staple crops for public health.",
      "Promote biosafety and regulatory standards in biotechnology.",
      "Provide high-level training and capacity building for researchers.",
      "Facilitate knowledge transfer from laboratory to farm."
    ],
    values: [
      { icon: "Target", title: "Excellence", description: "Committed to the highest standards of scientific research and integrity." },
      { icon: "Eye", title: "Innovation", description: "Continuously seeking new ways to solve agricultural challenges through biotechnology." },
      { icon: "Users", title: "Collaboration", description: "Working together with global partners, farmers, and the community." },
      { icon: "ShieldCheck", title: "Sustainability", description: "Prioritizing environmental health and long-term food security." },
    ]
  },
  research: {
    categories: ["All", "Crops", "Protection", "Health", "Technology"],
    projects: [
      {
        id: 1,
        title: "Climate-Resilient Maize",
        category: "Crops",
        description: "Engineering maize varieties that can withstand prolonged droughts and extreme temperatures.",
        image: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=800"
      },
      {
        id: 2,
        title: "Biopesticide Development",
        category: "Protection",
        description: "Creating natural alternatives to synthetic pesticides using microbial extracts.",
        image: "https://images.unsplash.com/photo-1530836361253-efad5cb2fe21?auto=format&fit=crop&q=80&w=800"
      },
      {
        id: 3,
        title: "Nutritional Biofortification",
        category: "Health",
        description: "Increasing essential micronutrients in staple crops like sweet potato and rice.",
        image: "https://images.unsplash.com/photo-1495107336281-19d368e7456d?auto=format&fit=crop&q=80&w=800"
      },
      {
        id: 4,
        title: "Bioinformatics Platform",
        category: "Technology",
        description: "Establishing a national database for agricultural genetic resources.",
        image: "https://images.unsplash.com/photo-1518152006812-edab29b069ac?auto=format&fit=crop&q=80&w=800"
      }
    ]
  },
  services: {
    main: [
      {
        title: "DNA Analysis",
        description: "Precise genetic sequencing and analysis for crops, livestock, and microorganisms.",
        image: "https://images.unsplash.com/photo-1579154204601-01588f351e67?auto=format&fit=crop&q=80&w=800"
      },
      {
        title: "Pathogen Testing",
        description: "Rapid detection of viral, bacterial, and fungal diseases in agricultural products.",
        image: "https://images.unsplash.com/photo-1581093588401-fbb62a02f120?auto=format&fit=crop&q=80&w=800"
      },
      {
        title: "Professional Training",
        description: "Capacity building workshops for scientists, farmers, and biotech entrepreneurs.",
        image: "https://images.unsplash.com/photo-1524178232363-1fb28f74b671?auto=format&fit=crop&q=80&w=800"
      }
    ],
    specialized: [
      { icon: "FlaskConical", title: "Genomic Sequencing", detail: "Next-gen sequencing for diverse agricultural species." },
      { icon: "Microscope", title: "Tissue Culture", detail: "Mass propagation of elite, disease-free plant varieties." },
      { icon: "ShieldCheck", title: "Biosafety Audit", detail: "Ensuring compliance with national biotechnology regulations." },
      { icon: "GraduationCap", title: "Student Internship", detail: "Practical hands-on training for biotech and agriculture students." },
    ],
    steps: [
      { title: "Inquiry", description: "Contact our services division with your specific requirements." },
      { title: "Quotation", description: "Receive a detailed proposal and timeline for the requested work." },
      { title: "Execution", description: "Our team executes the project with highest scientific standards." }
    ]
  },
  news: {
    articles: [
      {
        title: "New Biotech Hub Opens at NABRC",
        excerpt: "The hub will facilitate collaboration between industry players and academic researchers.",
        date: "Oct 24, 2023",
        category: "News",
        image: "https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&q=80&w=800"
      },
      {
        title: "Breakthrough in Wheat Rust Resistance",
        excerpt: "Our team has identified genes that provide robust resistance to devastating wheat rust variants.",
        date: "Oct 15, 2023",
        category: "Research",
        image: "https://images.unsplash.com/photo-1473615695634-d284ec918736?auto=format&fit=crop&q=80&w=800"
      },
      {
        title: "Upcoming: Annual Biotech Symposium 2024",
        excerpt: "Registration is now open for our flagship event gathering experts from across the continent.",
        date: "Oct 05, 2023",
        category: "Events",
        image: "https://images.unsplash.com/photo-1540575861501-7ad060e1c83e?auto=format&fit=crop&q=80&w=800"
      }
    ],
    events: [
      { title: "Genomics Workshop", date: "Nov 12" },
      { title: "Public Lecture on GMOs", date: "Nov 25" },
      { title: "Sustainable Ag Expo", date: "Dec 05" }
    ]
  },
  publications: {
    papers: [
      {
        title: "Genome-wide association mapping of drought tolerance in tropical maize",
        authors: "Dr. Elena Vance, Prof. Samuel Okafor, et al.",
        date: "Sept 2023",
        journal: "Nature Plants"
      },
      {
        title: "Sustainable biopesticide production using local fungal isolates",
        authors: "Michael Chen, Sarah Green",
    date: "Aug 2023",
    journal: "Biotech Progress"
  },
  {
    title: "NABRC Annual Institutional Report 2022-2023",
    authors: "Institutional Publication",
    date: "July 2023",
    journal: "Annual Report"
  },
  {
    title: "CRISPR-Cas9 mediated editing of rice for bacterial blight resistance",
    authors: "Dr. Robert Singh, Li Wei",
    date: "June 2023",
    journal: "Plant Science Journal"
  },
  {
    title: "Analysis of soil microbiome diversity in organic farming systems",
    authors: "Jessica Taylor, Mark Wilson",
    date: "May 2023",
    journal: "Applied Ecology"
  },
  {
    title: "Guidelines for Biosafety Regulation in Biotechnology Research",
    authors: "Policy Division",
    date: "April 2023",
    journal: "Policy Manual"
  }
    ],
    resources: [
      "Laboratory Protocols",
      "Biosafety Manuals",
      "Submission Templates",
      "Equipment Manuals"
    ]
  },
  gallery: {
    albums: [
      { title: "Main Laboratory", count: 12, image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/hero-lab-ce9bd47c-1774609488184.webp" },
      { title: "Experimental Greenhouse", count: 8, image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/greenhouse-research-30ff5e8b-1774609487798.webp" },
      { title: "Field Trials", count: 15, image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/hero-field-f97372cf-1774609488005.webp" },
      { title: "Training Programs", count: 20, image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/training-center-3ccfa164-1774609493055.webp" },
    ],
    recent: [
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/research-dna-65357148-1774609488185.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/researcher-microscope-549425fb-1774609488348.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/lab-services-fa3cd518-1774609488847.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/hero-lab-ce9bd47c-1774609488184.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/greenhouse-research-30ff5e8b-1774609487798.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/hero-field-f97372cf-1774609488005.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/training-center-3ccfa164-1774609493055.webp",
      "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1530836361253-efad5cb2fe21?auto=format&fit=crop&q=80&w=800"
    ]
  },
  contact: {
    info: {
      address: "123 Biotech Ave, Research Park, Science City, SC 45678",
      phone: "+1 (234) 567-8900",
      email: "info@nabrc.gov"
    },
    hours: [
      { days: "Monday - Friday", hours: "8:00 AM - 5:00 PM" },
      { days: "Saturday", hours: "9:00 AM - 1:00 PM" },
      { days: "Sunday", hours: "Closed", closed: true }
    ]
  }
};