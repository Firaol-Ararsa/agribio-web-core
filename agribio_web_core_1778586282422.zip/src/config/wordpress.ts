export const WORDPRESS_CONFIG = {
  /**
   * Set this to your WordPress site URL (e.g., 'https://your-wp-site.com')
   * If empty or undefined, the application will use the local mock data.
   */
  baseUrl: 'https://www.nabrc.com',
  
  /**
   * The REST API namespace. Default is 'wp/v2'.
   */
  namespace: 'wp/v2',
  
  /**
   * Map your custom post types here if they differ from the defaults.
   */
  postTypes: {
    research: 'research_project',
    services: 'service',
    publications: 'publication',
    news: 'posts',
  }
};

/**
 * Exported for compatibility with external references
 */
export const WORDPRESS_API_URL = `${WORDPRESS_CONFIG.baseUrl}/wp-json/`;

export const isWordPressEnabled = () => !!WORDPRESS_CONFIG.baseUrl;

export const getWpUrl = (endpoint: string) => {
  const base = WORDPRESS_CONFIG.baseUrl.replace(/\/$/, '');
  return `${base}/wp-json/${WORDPRESS_CONFIG.namespace}/${endpoint}`;
};