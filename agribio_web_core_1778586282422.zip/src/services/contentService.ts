import { siteContent, ContentData } from '../data/site-content';
import { isWordPressEnabled, getWpUrl } from '../config/wordpress';

class ContentService {
  private data: ContentData = siteContent;

  /**
   * Generic fetcher with fallback
   */
  private async fetchFromWp<T>(endpoint: string, fallback: T): Promise<T> {
    if (!isWordPressEnabled()) return fallback;

    try {
      const response = await fetch(getWpUrl(endpoint));
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.warn(`WordPress fetch failed for ${endpoint}, using fallback.`, error);
      return fallback;
    }
  }

  async getAllContent(): Promise<ContentData> {
    if (!isWordPressEnabled()) {
      return new Promise((resolve) => {
        setTimeout(() => resolve(this.data), 100);
      });
    }

    // In a real headless setup, you might fetch all main data in parallel
    // or fetch per page. For this transition, we'll return the full structure.
    return {
      ...this.data,
      // We can override specific sections if they exist in WP
      news: {
        ...this.data.news,
        articles: await this.getNewsArticles()
      },
      research: {
        ...this.data.research,
        projects: await this.getResearchProjects()
      }
    };
  }

  async getNewsArticles() {
    if (!isWordPressEnabled()) return this.data.news.articles;

    const wpPosts: any[] = await this.fetchFromWp('posts?_embed', []);
    return wpPosts.map(post => ({
      title: post.title.rendered,
      excerpt: post.excerpt.rendered.replace(/<[^>]*>?/gm, '').substring(0, 150) + '...',
      date: new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      category: post._embedded?.['wp:term']?.[0]?.[0]?.name || 'News',
      image: post._embedded?.['wp:featuredmedia']?.[0]?.source_url || this.data.news.articles[0].image
    }));
  }

  async getResearchProjects() {
    if (!isWordPressEnabled()) return this.data.research.projects;

    const wpProjects: any[] = await this.fetchFromWp('research_project?_embed', []);
    if (wpProjects.length === 0) return this.data.research.projects;

    return wpProjects.map((project, index) => ({
      id: project.id || index + 1,
      title: project.title.rendered,
      category: project._embedded?.['wp:term']?.[0]?.[0]?.name || 'General',
      description: project.excerpt?.rendered.replace(/<[^>]*>?/gm, '') || project.content.rendered.replace(/<[^>]*>?/gm, '').substring(0, 100),
      image: project._embedded?.['wp:featuredmedia']?.[0]?.source_url || this.data.research.projects[0].image
    }));
  }

  // Simplified getters for specific pages
  async getHomeContent() { return (await this.getAllContent()).home; }
  async getAboutContent() { return (await this.getAllContent()).about; }
  async getResearchContent() { return (await this.getAllContent()).research; }
  async getServicesContent() { return (await this.getAllContent()).services; }
  async getNewsContent() { return (await this.getAllContent()).news; }
  async getPublicationsContent() { return (await this.getAllContent()).publications; }
  async getGalleryContent() { return (await this.getAllContent()).gallery; }
  async getContactContent() { return (await this.getAllContent()).contact; }
  async getImages() { return (await this.getAllContent()).images; }
}

export const contentService = new ContentService();