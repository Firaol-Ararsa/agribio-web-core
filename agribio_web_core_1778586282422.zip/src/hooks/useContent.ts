import { useState, useEffect } from 'react';
import { contentService } from '../services/contentService';
import { ContentData } from '../data/site-content';

export function useContent() {
  const [content, setContent] = useState<ContentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    async function loadContent() {
      try {
        const data = await contentService.getAllContent();
        setContent(data);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to load content'));
      } finally {
        setLoading(false);
      }
    }

    loadContent();
  }, []);

  return { content, loading, error };
}