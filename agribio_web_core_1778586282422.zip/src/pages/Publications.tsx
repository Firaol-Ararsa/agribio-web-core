import { useState } from 'react';
import { Section, PageHeader } from '../components/Section';
import { PublicationCard } from '../components/Card';
import { Search, Download, Filter } from 'lucide-react';
import { useContent } from '../hooks/useContent';

export default function Publications() {
  const { content, loading } = useContent();
  const [searchQuery, setSearchQuery] = useState("");

  if (loading || !content) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-600"></div>
      </div>
    );
  }

  const filteredPublications = content.publications.papers.filter(pub => 
    pub.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pub.authors.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="pt-20">
      <PageHeader 
        title="Publications" 
        subtitle="Scientific papers, technical reports, and institutional resources."
        image={content.images.publications}
      />

      <Section>
        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-12">
          <div className="relative flex-grow">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input 
              type="text" 
              placeholder="Search by title, author, or keyword..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-green-500 focus:outline-none bg-white shadow-sm"
            />
          </div>
          <button className="px-6 py-4 bg-white border border-slate-200 rounded-xl flex items-center text-slate-600 font-semibold hover:bg-slate-50">
            <Filter className="w-5 h-5 mr-2" />
            Filter
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredPublications.map((pub, i) => (
            <PublicationCard key={i} {...pub} />
          ))}
        </div>

        {filteredPublications.length === 0 && (
          <div className="text-center py-20">
            <p className="text-slate-500 text-lg">No publications found matching your search.</p>
          </div>
        )}

        {/* Resources Section */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold mb-8">Resources for Researchers</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {content.publications.resources.map((res, i) => (
              <div key={i} className="p-6 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between hover:border-green-300 transition-colors cursor-pointer group">
                <span className="font-bold text-slate-800">{res}</span>
                <Download className="w-5 h-5 text-slate-400 group-hover:text-green-600" />
              </div>
            ))}
          </div>
        </div>
      </Section>
    </div>
  );
}