import { motion } from 'framer-motion';
import { Section, PageHeader } from '../components/Section';
import { useContent } from '../hooks/useContent';
import { IconMap } from '../data/site-content';
import { Target } from 'lucide-react';

export default function About() {
  const { content, loading } = useContent();

  if (loading || !content) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <PageHeader 
        title="About NABRC" 
        subtitle="The National Agricultural Biotechnology Research Center is a premier institution dedicated to advancing life sciences in agriculture."
        image={content.images.greenhouse}
      />

      <Section>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-slate-900">Our Mission</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              {content.about.mission}
            </p>
            <h2 className="text-3xl font-bold text-slate-900 pt-8">Our Vision</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              {content.about.vision}
            </p>
          </div>
          <div className="bg-green-50 p-8 rounded-3xl border border-green-100">
            <h3 className="text-2xl font-bold text-green-800 mb-6">Institutional Objectives</h3>
            <ul className="space-y-4">
              {content.about.objectives.map((obj, i) => (
                <li key={i} className="flex items-start space-x-3">
                  <div className="mt-1.5 w-2 h-2 rounded-full bg-green-600 shrink-0" />
                  <span className="text-slate-700 font-medium">{obj}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      <Section className="bg-slate-900 text-white">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Our Core Values</h2>
          <p className="text-slate-400">The principles that guide our research and institutional culture.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {content.about.values.map((v, i) => {
            const Icon = IconMap[v.icon] || Target;
            return (
              <motion.div
                key={i}
                whileHover={{ y: -5 }}
                className="p-8 bg-white/5 border border-white/10 rounded-2xl text-center"
              >
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-green-600/20 text-green-400 mb-6">
                  <Icon className="w-7 h-7" />
                </div>
                <h4 className="text-xl font-bold mb-3">{v.title}</h4>
                <p className="text-sm text-slate-400 leading-relaxed">{v.description}</p>
              </motion.div>
            );
          })}
        </div>
      </Section>

      <Section>
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Organizational Structure</h2>
          <p className="text-slate-600">NABRC operates under a robust governance model to ensure scientific excellence and efficiency.</p>
        </div>
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col items-center">
            <div className="p-6 bg-green-700 text-white rounded-xl font-bold w-64 text-center mb-8 shadow-lg">Board of Directors</div>
            <div className="w-0.5 h-12 bg-slate-200 mb-8" />
            <div className="p-6 bg-slate-800 text-white rounded-xl font-bold w-64 text-center mb-8 shadow-md">Director General</div>
            <div className="w-0.5 h-12 bg-slate-200" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8 w-full">
              <div className="p-6 bg-white border border-slate-200 rounded-xl text-center shadow-sm">
                <h5 className="font-bold text-slate-800 mb-2">Research Division</h5>
                <p className="text-xs text-slate-500">Crops, Animals, Microbes</p>
              </div>
              <div className="p-6 bg-white border border-slate-200 rounded-xl text-center shadow-sm">
                <h5 className="font-bold text-slate-800 mb-2">Operations Division</h5>
                <p className="text-xs text-slate-500">Finance, HR, Logistics</p>
              </div>
              <div className="p-6 bg-white border border-slate-200 rounded-xl text-center shadow-sm">
                <h5 className="font-bold text-slate-800 mb-2">Services Division</h5>
                <p className="text-xs text-slate-500">Labs, Training, Extension</p>
              </div>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}