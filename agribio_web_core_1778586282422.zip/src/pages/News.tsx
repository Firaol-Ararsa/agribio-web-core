import { Section, PageHeader } from '../components/Section';
import { Calendar } from 'lucide-react';
import { useContent } from '../hooks/useContent';

export default function News() {
  const { content, loading } = useContent();

  if (loading || !content) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <PageHeader 
        title="News & Events" 
        subtitle="The latest updates from the forefront of agricultural biotechnology."
        image={content.images.training}
      />

      <Section>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main News Area */}
          <div className="lg:col-span-2 space-y-12">
            {content.news.articles.map((news, i) => (
              <div key={i} className="flex flex-col md:flex-row gap-8 group">
                <div className="md:w-1/3 h-64 rounded-2xl overflow-hidden shrink-0">
                  <img src={news.image} alt={news.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                </div>
                <div className="flex-grow">
                  <div className="flex items-center space-x-4 mb-4">
                    <span className="px-3 py-1 bg-green-50 text-green-700 text-xs font-bold rounded-full">{news.category}</span>
                    <span className="text-slate-400 text-sm flex items-center"><Calendar className="w-4 h-4 mr-1" /> {news.date}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4 group-hover:text-green-700 transition-colors">{news.title}</h3>
                  <p className="text-slate-600 mb-6 leading-relaxed">{news.excerpt}</p>
                  <button className="text-slate-900 font-bold border-b-2 border-green-600 pb-1 hover:text-green-700 transition-colors">Read Article</button>
                </div>
              </div>
            ))}
          </div>

          {/* Sidebar */}
          <aside className="space-y-12">
            <div className="bg-slate-50 p-8 rounded-2xl">
              <h4 className="text-xl font-bold text-slate-900 mb-6">Upcoming Events</h4>
              <div className="space-y-6">
                {content.news.events.map((ev, i) => (
                  <div key={i} className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-white rounded-lg flex flex-col items-center justify-center border text-green-700 font-bold">
                      <span className="text-xs leading-none">{ev.date.split(' ')[0]}</span>
                      <span className="text-sm">{ev.date.split(' ')[1]}</span>
                    </div>
                    <span className="font-semibold text-slate-800 hover:text-green-600 cursor-pointer">{ev.title}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-green-600 p-8 rounded-2xl text-white">
              <h4 className="text-xl font-bold mb-4">Newsletter</h4>
              <p className="text-sm text-green-100 mb-6">Get weekly updates directly in your inbox.</p>
              <input type="email" placeholder="Email Address" className="w-full px-4 py-3 rounded-lg bg-green-700 border-none placeholder:text-green-300 text-white mb-4" />
              <button className="w-full py-3 bg-white text-green-700 font-bold rounded-lg">Subscribe</button>
            </div>
          </aside>
        </div>
      </Section>
    </div>
  );
}