# NABRC WordPress Integration Guide

This project has been converted to support a **Headless WordPress** architecture while maintaining its modern React frontend.

## How it Works
1.  **Frontend**: The React application (Vite + Tailwind) remains the user-facing interface.
2.  **Backend**: WordPress serves as the Content Management System (CMS) via its REST API.
3.  **Communication**: The `contentService.ts` fetches data from WordPress and maps it to the React components.

## Setup Instructions

### 1. WordPress Backend Setup
1.  Install a fresh WordPress instance.
2.  Install the **Advanced Custom Fields (ACF)** plugin (optional but recommended for more complex data).
3.  Add the files from the `/wordpress-theme` directory into a new folder in `wp-content/themes/nabrc-theme`.
4.  Activate the "NABRC React Theme" in the WordPress Dashboard.
5.  Go to **Settings > Permalinks** and set them to "Post name".

### 2. Configure React Frontend
1.  Open `src/config/wordpress.ts`.
2.  Set `baseUrl` to your WordPress site URL (e.g., `https://your-wp-site.com`).
3.  The app will automatically switch from using local mock data to fetching from your WordPress REST API.

### 3. Creating Content
-   **News**: Create standard WordPress Posts. They will appear in the "News" section.
-   **Research**: Use the "Research Projects" custom post type (registered in `functions.php`).
-   **Services**: Use the "Services" custom post type.

### 4. Deployment
1.  Run `npm run build` to generate the production build.
2.  Copy the contents of the `dist` folder into your `wp-content/themes/nabrc-theme/dist` directory.
3.  WordPress will now serve your React app directly!

## Benefits of this Approach
-   **Performance**: Blazing fast React frontend with modern transitions.
-   **SEO**: React Router and standard metadata handled by the frontend.
-   **Ease of Use**: Non-technical staff can update content using the familiar WordPress dashboard.
-   **Security**: Decoupled architecture reduces the attack surface of the backend.