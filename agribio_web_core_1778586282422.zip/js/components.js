const Components = {
    Navbar: () => `
        <nav class="bg-white border-b sticky top-0 z-40">
            <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3 cursor-pointer" onclick="window.location.hash='home'">
                    <div class="bg-primary p-2 rounded-lg">
                        <i data-lucide="dna" class="text-white w-6 h-6"></i>
                    </div>
                    <div>
                        <h1 class="font-bold text-xl text-primary leading-tight">NABRC</h1>
                        <p class="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">National Biotechnology</p>
                    </div>
                </div>
                <div class="hidden md:flex gap-8 text-sm font-medium">
                    <a href="#home" class="nav-link transition-colors hover:text-primary" data-nav="home">Home</a>
                    <a href="#about" class="nav-link transition-colors hover:text-primary" data-nav="about">About</a>
                    <a href="#research" class="nav-link transition-colors hover:text-primary" data-nav="research">Research</a>
                    <a href="#services" class="nav-link transition-colors hover:text-primary" data-nav="services">Services</a>
                    <a href="#news" class="nav-link transition-colors hover:text-primary" data-nav="news">News</a>
                    <a href="#gallery" class="nav-link transition-colors hover:text-primary" data-nav="gallery">Gallery</a>
                    <a href="#publications" class="nav-link transition-colors hover:text-primary" data-nav="publications">Publications</a>
                    <a href="#contact" class="nav-link transition-colors hover:text-primary" data-nav="contact">Contact</a>
                </div>
                <button class="md:hidden p-2 text-slate-600" id="mobile-menu-btn">
                    <i data-lucide="menu"></i>
                </button>
            </div>
            <!-- Mobile Menu -->
            <div id="mobile-menu" class="hidden md:hidden bg-white border-b absolute w-full left-0 p-4 shadow-lg flex flex-col gap-4">
                <a href="#home" class="font-bold text-primary">Home</a>
                <a href="#about">About</a>
                <a href="#research">Research</a>
                <a href="#services">Services</a>
                <a href="#news">News</a>
                <a href="#gallery">Gallery</a>
                <a href="#publications">Publications</a>
                <a href="#contact">Contact</a>
            </div>
        </nav>
    `,

    Footer: () => `
        <footer class="bg-primary text-white pt-16 pb-8">
            <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
                <div class="col-span-1 md:col-span-1">
                    <div class="flex items-center gap-3 mb-6">
                        <div class="bg-white/10 p-2 rounded-lg">
                            <i data-lucide="dna" class="text-white w-6 h-6"></i>
                        </div>
                        <h2 class="font-bold text-2xl tracking-tight text-emerald-100">NABRC</h2>
                    </div>
                    <p class="text-emerald-100/70 text-sm leading-relaxed mb-6 italic">
                        "Advancing Ethiopian agriculture through innovative biotechnology research and development."
                    </p>
                </div>
                <div>
                    <h3 class="font-bold mb-6 text-emerald-300 uppercase text-xs tracking-widest">Quick Links</h3>
                    <ul class="space-y-3 text-sm text-emerald-100/80">
                        <li><a href="#about" class="hover:text-white transition-colors">Our History</a></li>
                        <li><a href="#research" class="hover:text-white transition-colors">Current Projects</a></li>
                        <li><a href="#publications" class="hover:text-white transition-colors">Research Papers</a></li>
                        <li><a href="#contact" class="hover:text-white transition-colors">Work with Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="font-bold mb-6 text-emerald-300 uppercase text-xs tracking-widest">Our Focus</h3>
                    <ul class="space-y-3 text-sm text-emerald-100/80">
                        <li><a href="#services" class="hover:text-white transition-colors">Laboratory Testing</a></li>
                        <li><a href="#services" class="hover:text-white transition-colors">Capacity Building</a></li>
                        <li><a href="#services" class="hover:text-white transition-colors">Bio-consultancy</a></li>
                        <li><a href="#services" class="hover:text-white transition-colors">Seed Quality Lab</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="font-bold mb-6 text-emerald-300 uppercase text-xs tracking-widest">Contact Info</h3>
                    <ul class="space-y-4 text-sm text-emerald-100/80">
                        <li class="flex gap-3">
                            <i data-lucide="map-pin" class="w-5 h-5 text-emerald-400 shrink-0"></i>
                            <span>Bishoftu, Oromia, Ethiopia</span>
                        </li>
                        <li class="flex gap-3">
                            <i data-lucide="phone" class="w-5 h-5 text-emerald-400 shrink-0"></i>
                            <span>+251 11 433 8555</span>
                        </li>
                        <li class="flex gap-3">
                            <i data-lucide="mail" class="w-5 h-5 text-emerald-400 shrink-0"></i>
                            <span>info@nabrc.gov.et</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-16 pt-8 border-t border-white/5 text-center text-[10px] text-emerald-300/50 uppercase tracking-[0.2em]">
                <p>&copy; ${new Date().getFullYear()} National Agricultural Biotechnology Research Center</p>
            </div>
        </footer>
    `,

    Card: (title, desc, image, meta = '') => `
        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden group hover:shadow-xl transition-all duration-500">
            <div class="h-56 overflow-hidden relative">
                <img src="${image}" alt="${title}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy">
                ${meta ? `<div class="absolute top-4 left-4 bg-primary text-white text-[10px] px-3 py-1.5 rounded-full font-bold uppercase tracking-widest backdrop-blur-md bg-opacity-90 shadow-lg">${meta}</div>` : ''}
            </div>
            <div class="p-8">
                <h3 class="font-bold text-xl mb-3 group-hover:text-primary transition-colors leading-tight">${title}</h3>
                <p class="text-slate-500 text-sm line-clamp-3 leading-relaxed mb-6">${desc}</p>
                <div class="flex items-center justify-between mt-auto pt-4 border-t border-slate-50">
                    <span class="text-primary text-sm font-bold flex items-center gap-1 group/btn cursor-pointer">
                        View Details <i data-lucide="arrow-right" class="w-4 h-4 group-hover/btn:translate-x-1 transition-transform"></i>
                    </span>
                    <i data-lucide="share-2" class="w-4 h-4 text-slate-300 hover:text-primary cursor-pointer transition-colors"></i>
                </div>
            </div>
        </div>
    `,

    Loader: () => `
        <div class="flex flex-col items-center justify-center py-40">
            <div class="loader mb-6"></div>
            <div class="flex flex-col items-center gap-2">
                <p class="text-primary font-bold tracking-widest uppercase text-xs">NABRC</p>
                <p class="text-slate-400 text-[10px] animate-pulse">Establishing Scientific Connection...</p>
            </div>
        </div>
    `
};