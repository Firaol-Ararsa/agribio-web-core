const CONFIG = {
    WP_URL: 'https://www.eiar.gov.et/nabrc',
    API_NAMESPACE: 'wp-json/wp/v2',
    WP_ENABLED: true,
    IMAGES: {
        hero: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/hero-background-39a1c8d8-1778232344570.webp',
        research1: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/research-highlight-1-97aac20f-1778232346675.webp',
        research2: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/research-highlight-2-7451c77b-1778232346660.webp',
        service: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/lab-services-2c8e52ad-1778232346060.webp',
        campus: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/nabrc-campus-7e5f1f7d-1778232344436.webp',
        news: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/589cdc73-9720-44ec-b16b-412039038348/news-and-events-cd1ee0b0-1778232346664.webp'
    }
};

const FALLBACK_DATA = {
    news: [
        { title: 'New Maize Variety Released', excerpt: 'NABRC scientists have developed a drought-resistant maize variety...', date: 'Oct 12, 2023', category: 'Research', image: CONFIG.IMAGES.news },
        { title: 'Biotechnology Workshop 2024', excerpt: 'Join us for the upcoming international workshop on crop improvement...', date: 'Nov 05, 2023', category: 'Events', image: CONFIG.IMAGES.research2 }
    ],
    projects: [
        { title: 'Genetic Improvement of Wheat', category: 'Crop Research', description: 'Enhancing wheat yields through molecular breeding techniques.', image: CONFIG.IMAGES.research1 },
        { title: 'Coffee Wilt Disease Management', category: 'Plant Pathology', description: 'Developing biotechnology-based solutions for coffee diseases.', image: CONFIG.IMAGES.research2 }
    ]
};