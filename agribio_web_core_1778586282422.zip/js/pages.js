const Pages = {
    Home: async () => {
        const news = await API.getNews();
        return `
            <div class="page-transition">
                <!-- Hero Section -->
                <section class="relative h-[85vh] flex items-center overflow-hidden bg-slate-900">
                    <img src="${CONFIG.IMAGES.hero}" class="absolute inset-0 w-full h-full object-cover opacity-60" />
                    <div class="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/60 to-transparent"></div>
                    <div class="relative max-w-7xl mx-auto px-4 w-full">
                        <div class="max-w-2xl">
                            <span class="inline-block px-3 py-1 bg-primary text-white text-[10px] font-bold tracking-widest uppercase rounded-full mb-6">Ethiopian Agricultural Research</span>
                            <h1 class="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-[1.1]">Unlocking the <span class="text-emerald-400">Future</span> of Agriculture.</h1>
                            <p class="text-lg md:text-xl text-slate-200 mb-10 leading-relaxed font-light">
                                Empowering Ethiopia's agricultural landscape through cutting-edge biotechnology research, innovative seed solutions, and sustainable farming practices.
                            </p>
                            <div class="flex flex-col sm:flex-row gap-4">
                                <a href="#research" class="px-8 py-4 bg-primary text-white font-bold rounded-xl hover:bg-emerald-700 transition-all text-center shadow-lg shadow-emerald-900/20">Explore Research</a>
                                <a href="#about" class="px-8 py-4 bg-white text-primary font-bold rounded-xl hover:bg-slate-100 transition-all text-center border border-white">Our Mission</a>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Stats Section -->
                <section class="relative -mt-16 pb-16">
                    <div class="max-w-7xl mx-auto px-4">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            ${[
                                { label: 'Active Projects', val: '24+', icon: 'flask-conical' },
                                { label: 'Scientific Staff', val: '120+', icon: 'users' },
                                { label: 'Research Areas', val: '8', icon: 'microscope' },
                                { label: 'Years of Excellence', val: '15+', icon: 'award' }
                            ].map(stat => `
                                <div class="bg-white p-6 rounded-2xl shadow-xl border border-slate-100 text-center hover:translate-y-[-5px] transition-transform">
                                    <div class="w-12 h-12 bg-emerald-50 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                                        <i data-lucide="${stat.icon}" class="w-6 h-6"></i>
                                    </div>
                                    <div class="text-3xl font-black text-slate-900 mb-1">${stat.val}</div>
                                    <div class="text-[10px] text-slate-500 uppercase tracking-widest font-bold">${stat.label}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </section>

                <!-- Highlights Section -->
                <section class="py-24 bg-white">
                    <div class="max-w-7xl mx-auto px-4">
                        <div class="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
                            <div class="max-w-xl">
                                <h2 class="text-3xl font-bold mb-4 flex items-center gap-3">
                                    <span class="w-8 h-1 bg-primary rounded-full"></span>
                                    Core Research Areas
                                </h2>
                                <p class="text-slate-600 leading-relaxed">We focus on high-impact biotechnology solutions tailored for Ethiopia's unique ecological zones and crops.</p>
                            </div>
                            <a href="#research" class="text-primary font-bold hover:underline">View All Projects</a>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                            ${Components.Card('Genomic Selection', 'Accelerating the breeding cycle of critical Ethiopian crops through advanced DNA marker selection.', CONFIG.IMAGES.research1, 'Genomics')}
                            ${Components.Card('Micro-propagation', 'Large-scale production of high-quality, disease-free planting materials for highland crops.', CONFIG.IMAGES.research2, 'Tissue Culture')}
                            ${Components.Card('Stress Resilience', 'Developing varieties resistant to drought, salinity, and local pathogens through genetic engineering.', CONFIG.IMAGES.service, 'Resilience')}
                        </div>
                    </div>
                </section>

                <!-- News Section -->
                <section class="py-24 bg-slate-50">
                    <div class="max-w-7xl mx-auto px-4">
                        <div class="text-center mb-16">
                            <h2 class="text-3xl font-bold mb-4">Latest from NABRC</h2>
                            <p class="text-slate-600">Stay updated with our newest discoveries and institutional announcements.</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                            ${news.slice(0, 3).map(n => Components.Card(n.title, n.excerpt, n.image, n.category)).join('')}
                        </div>
                    </div>
                </section>
            </div>
        `;
    },

    About: async () => `
        <div class="page-transition">
            <section class="bg-primary py-24 text-white">
                <div class="max-w-7xl mx-auto px-4">
                    <h1 class="text-5xl font-black mb-6">About the Center</h1>
                    <p class="text-xl text-emerald-100 max-w-2xl leading-relaxed">Leading the scientific transformation of Ethiopian agriculture since 2008.</p>
                </div>
            </section>
            <section class="py-24 max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-16">
                <div>
                    <img src="${CONFIG.IMAGES.campus}" class="rounded-2xl shadow-2xl mb-8" />
                    <div class="grid grid-cols-2 gap-4">
                        <div class="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                            <h4 class="font-bold text-primary mb-2">Vision</h4>
                            <p class="text-sm text-slate-600">To be a world-class agricultural biotechnology excellence center by 2030.</p>
                        </div>
                        <div class="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                            <h4 class="font-bold text-primary mb-2">Mission</h4>
                            <p class="text-sm text-slate-600">To enhance agricultural productivity and quality through biotechnology research.</p>
                        </div>
                    </div>
                </div>
                <div>
                    <h2 class="text-3xl font-bold mb-8 text-slate-900">Institutional Mandate</h2>
                    <div class="space-y-6 text-slate-600 leading-relaxed">
                        <p>The National Agricultural Biotechnology Research Center (NABRC) is a premier institution under the Ethiopian Institute of Agricultural Research (EIAR).</p>
                        <p>Our mandate includes coordinating and conducting biotechnology research in crop, livestock, and microbial sectors to address national priorities in food security and environmental sustainability.</p>
                        <h3 class="text-xl font-bold text-slate-900 mt-12 mb-4">Core Objectives</h3>
                        <ul class="space-y-4">
                            <li class="flex gap-4">
                                <i data-lucide="check-circle" class="text-primary w-6 h-6 shrink-0"></i>
                                <span>Generating high-yielding and resilient agricultural technologies.</span>
                            </li>
                            <li class="flex gap-4">
                                <i data-lucide="check-circle" class="text-primary w-6 h-6 shrink-0"></i>
                                <span>Establishing national biosafety and quality control standards.</span>
                            </li>
                            <li class="flex gap-4">
                                <i data-lucide="check-circle" class="text-primary w-6 h-6 shrink-0"></i>
                                <span>Building human and infrastructural capacity in biotechnology.</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </section>
        </div>
    `,

    Research: async () => {
        const projects = await API.getResearch();
        return `
            <div class="page-transition">
                <section class="bg-slate-900 py-24 text-white relative overflow-hidden">
                    <img src="${CONFIG.IMAGES.research1}" class="absolute inset-0 w-full h-full object-cover opacity-20" />
                    <div class="relative max-w-7xl mx-auto px-4">
                        <h1 class="text-5xl font-black mb-6">Research & Projects</h1>
                        <p class="text-xl text-slate-300 max-w-2xl leading-relaxed">Explore our diverse portfolio of biotechnology initiatives aimed at solving real-world agricultural challenges.</p>
                    </div>
                </section>
                <section class="py-24 max-w-7xl mx-auto px-4">
                    <div class="flex flex-col md:flex-row gap-8 mb-16">
                        <div class="flex-grow">
                            <div class="relative group">
                                <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                                <input type="text" placeholder="Search projects by crop or technology..." class="w-full pl-12 pr-4 py-4 rounded-xl border border-slate-200 focus:border-primary focus:ring-4 focus:ring-emerald-50 focus:border-primary outline-none transition-all">
                            </div>
                        </div>
                        <div class="flex gap-2 overflow-x-auto pb-2">
                            <button class="whitespace-nowrap px-6 py-4 bg-primary text-white font-bold rounded-xl shadow-lg">All Areas</button>
                            <button class="whitespace-nowrap px-6 py-4 bg-white text-slate-600 font-bold rounded-xl border hover:border-primary hover:text-primary transition-all">Crop</button>
                            <button class="whitespace-nowrap px-6 py-4 bg-white text-slate-600 font-bold rounded-xl border hover:border-primary hover:text-primary transition-all">Livestock</button>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                        ${projects.map(p => Components.Card(p.title, p.description, p.image, p.category)).join('')}
                    </div>
                </section>
            </div>
        `;
    },

    Services: async () => `
        <div class="page-transition">
            <section class="bg-primary py-24 text-white">
                <div class="max-w-7xl mx-auto px-4 text-center">
                    <h1 class="text-5xl font-black mb-6 text-emerald-100 uppercase tracking-tighter">Scientific Services</h1>
                    <p class="text-xl text-emerald-50 max-w-2xl mx-auto leading-relaxed">Providing professional biotechnology services to researchers, farmers, and the private sector.</p>
                </div>
            </section>
            <section class="py-24 max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-12">
                ${[
                    { title: 'Laboratory Services', items: ['DNA Sequencing', 'Soil & Plant Analysis', 'Disease Diagnostics', 'Pathogen Identification'], icon: 'flask-conical' },
                    { title: 'Training Programs', items: ['Molecular Biology Basics', 'Bioinformatics Workshops', 'Lab Safety Management', 'Quality Control Systems'], icon: 'graduation-cap' },
                    { title: 'Consultancy', items: ['Biosafety Regulations', 'Technical Feasibility', 'Project Management', 'Tech Transfer Support'], icon: 'briefcase' }
                ].map(s => `
                    <div class="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-xl transition-all group">
                        <div class="w-14 h-14 bg-emerald-50 text-primary rounded-xl flex items-center justify-center mb-8 group-hover:bg-primary group-hover:text-white transition-all">
                            <i data-lucide="${s.icon}" class="w-8 h-8"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-6 text-slate-900">${s.title}</h3>
                        <ul class="space-y-4">
                            ${s.items.map(item => `
                                <li class="flex items-center gap-3 text-slate-600">
                                    <div class="w-1.5 h-1.5 rounded-full bg-emerald-400"></div>
                                    ${item}
                                </li>
                            `).join('')}
                        </ul>
                        <button class="mt-10 w-full py-4 border-2 border-emerald-50 text-primary font-bold rounded-xl group-hover:bg-primary group-hover:text-white group-hover:border-primary transition-all">Request Service</button>
                    </div>
                `).join('')}
            </section>
        </div>
    `,

    News: async () => {
        const news = await API.getNews();
        return `
            <div class="page-transition">
                <section class="py-24 max-w-7xl mx-auto px-4">
                    <div class="mb-16">
                        <h1 class="text-4xl font-black mb-4">News & Updates</h1>
                        <p class="text-slate-600">The latest developments and stories from the center.</p>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                        ${news.map(n => Components.Card(n.title, n.excerpt, n.image, `${n.category} | ${n.date}`)).join('')}
                    </div>
                </section>
            </div>
        `;
    },

    Publications: async () => `
        <div class="page-transition">
            <section class="py-24 max-w-7xl mx-auto px-4">
                <h1 class="text-4xl font-black mb-12">Scientific Publications</h1>
                <div class="bg-white rounded-2xl shadow-sm border overflow-hidden overflow-x-auto">
                    <table class="w-full text-left min-w-[600px]">
                        <thead class="bg-slate-50 border-b">
                            <tr>
                                <th class="px-6 py-4 font-bold text-sm text-slate-500 uppercase">Title</th>
                                <th class="px-6 py-4 font-bold text-sm text-slate-500 uppercase">Category</th>
                                <th class="px-6 py-4 font-bold text-sm text-slate-500 uppercase">Year</th>
                                <th class="px-6 py-4 font-bold text-sm text-slate-500 uppercase text-right">Download</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            ${[
                                { title: 'Drought Resilience in Ethiopian Highland Maize', cat: 'Journal Article', year: '2023' },
                                { title: 'Biosafety Protocols for GM Research', cat: 'Policy Manual', year: '2022' },
                                { title: 'Annual Progress Report 2023', cat: 'Institutional Report', year: '2023' },
                                { title: 'Molecular Markers in Coffee Selection', cat: 'Research Paper', year: '2021' }
                            ].map(pub => `
                                <tr class="hover:bg-slate-50 transition-colors">
                                    <td class="px-6 py-5 font-bold text-slate-900">${pub.title}</td>
                                    <td class="px-6 py-5"><span class="px-2 py-1 bg-slate-100 rounded text-xs text-slate-600 uppercase font-semibold">${pub.cat}</span></td>
                                    <td class="px-6 py-5 text-slate-600">${pub.year}</td>
                                    <td class="px-6 py-5 text-right"><i data-lucide="download" class="w-5 h-5 text-primary ml-auto cursor-pointer"></i></td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    `,

    Gallery: async () => `
        <div class="page-transition">
            <section class="bg-emerald-50 py-24">
                <div class="max-w-7xl mx-auto px-4 text-center">
                    <h1 class="text-4xl font-black mb-4">Center Gallery</h1>
                    <p class="text-slate-600 max-w-xl mx-auto">Visual glimpses of our research activities, facilities, and team.</p>
                </div>
            </section>
            <section class="py-24 max-w-7xl mx-auto px-4">
                <div class="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
                    ${[
                        CONFIG.IMAGES.hero, CONFIG.IMAGES.research1, CONFIG.IMAGES.research2,
                        CONFIG.IMAGES.service, CONFIG.IMAGES.campus, CONFIG.IMAGES.news
                    ].map((img, i) => `
                        <div class="break-inside-avoid rounded-2xl overflow-hidden shadow-sm group relative">
                            <img src="${img}" class="w-full h-auto object-cover group-hover:scale-110 transition-transform duration-700" />
                            <div class="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <i data-lucide="maximize" class="text-white w-10 h-10"></i>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </section>
        </div>
    `,

    Contact: async () => `
        <div class="page-transition">
            <section class="py-24 max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-20">
                <div>
                    <h1 class="text-4xl font-black mb-6">Contact Us</h1>
                    <p class="text-lg text-slate-600 mb-12">Have questions about our research or services? Get in touch with our team.</p>
                    
                    <div class="space-y-8">
                        <div class="flex gap-6">
                            <div class="w-12 h-12 bg-emerald-50 text-primary rounded-xl flex items-center justify-center shrink-0">
                                <i data-lucide="map-pin"></i>
                            </div>
                            <div>
                                <h4 class="font-bold mb-1">Our Location</h4>
                                <p class="text-slate-600">Bishoftu, Oromia Region, Ethiopia (EIAR Campus)</p>
                            </div>
                        </div>
                        <div class="flex gap-6">
                            <div class="w-12 h-12 bg-emerald-50 text-primary rounded-xl flex items-center justify-center shrink-0">
                                <i data-lucide="phone"></i>
                            </div>
                            <div>
                                <h4 class="font-bold mb-1">Phone Number</h4>
                                <p class="text-slate-600">+251 11 433 8555 / +251 11 433 8745</p>
                            </div>
                        </div>
                        <div class="flex gap-6">
                            <div class="w-12 h-12 bg-emerald-50 text-primary rounded-xl flex items-center justify-center shrink-0">
                                <i data-lucide="mail"></i>
                            </div>
                            <div>
                                <h4 class="font-bold mb-1">Email Address</h4>
                                <p class="text-slate-600">info@nabrc.gov.et / contact@eiar.gov.et</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-8">Send a Message</h3>
                    <form id="contact-form" class="space-y-6">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-xs font-bold uppercase text-slate-500 mb-2">First Name</label>
                                <input type="text" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-emerald-50 focus:border-primary outline-none transition-all">
                            </div>
                            <div>
                                <label class="block text-xs font-bold uppercase text-slate-500 mb-2">Last Name</label>
                                <input type="text" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-emerald-50 focus:border-primary outline-none transition-all">
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase text-slate-500 mb-2">Email Address</label>
                            <input type="email" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-emerald-50 focus:border-primary outline-none transition-all">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase text-slate-500 mb-2">Subject</label>
                            <select class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-emerald-50 focus:border-primary outline-none transition-all">
                                <option>Research Collaboration</option>
                                <option>Laboratory Services</option>
                                <option>Training Program Inquiry</option>
                                <option>General Information</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase text-slate-500 mb-2">Message</label>
                            <textarea rows="4" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-emerald-50 focus:border-primary outline-none transition-all"></textarea>
                        </div>
                        <button type="submit" class="w-full py-4 bg-primary text-white font-bold rounded-xl shadow-lg shadow-emerald-900/20 hover:bg-emerald-700 transition-all">Send Message</button>
                    </form>
                </div>
            </section>
        </div>
    `
};