const Router = {
    routes: {
        'home': Pages.Home,
        'about': Pages.About,
        'research': Pages.Research,
        'services': Pages.Services,
        'news': Pages.News,
        'publications': Pages.Publications,
        'gallery': Pages.Gallery,
        'contact': Pages.Contact
    },

    async handleRoute() {
        const app = document.getElementById('app');
        const hash = window.location.hash.replace('#', '') || 'home';
        
        // Update Navbar Active State
        document.querySelectorAll('[data-nav]').forEach(link => {
            if (link.dataset.nav === hash) {
                link.classList.add('active-nav');
            } else {
                link.classList.remove('active-nav');
            }
        });

        // Show Loader
        app.innerHTML = Components.Loader();
        updateIcons();

        // Load Page
        const pageFn = this.routes[hash] || this.routes['home'];
        try {
            const content = await pageFn();
            app.innerHTML = content;
            window.scrollTo(0, 0);
            updateIcons();
            this.bindEvents();
        } catch (error) {
            console.error('Routing error:', error);
            app.innerHTML = `<div class="p-20 text-center">
                <h2 class="text-2xl font-bold text-red-600 mb-4">Oops! Something went wrong.</h2>
                <button onclick="window.location.reload()" class="text-primary underline">Try reloading the page</button>
            </div>`;
        }
    },

    bindEvents() {
        const contactForm = document.getElementById('contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.showToast('Message sent successfully! We will get back to you soon.', 'success');
                contactForm.reset();
            });
        }
        
        // Handle mobile menu if implemented
        const menuBtn = document.querySelector('button[data-lucide="menu"]');
        if (menuBtn) {
            // Placeholder for mobile menu toggle
        }
    },

    showToast(message, type = 'success') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `p-4 rounded-xl shadow-2xl text-white font-bold mb-2 transition-all ${type === 'success' ? 'bg-emerald-600' : 'bg-red-600'}`;
        toast.innerText = message;
        container.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 500);
        }, 3000);
    },

    init() {
        window.addEventListener('hashchange', () => this.handleRoute());
        window.addEventListener('load', () => this.handleRoute());
    }
};