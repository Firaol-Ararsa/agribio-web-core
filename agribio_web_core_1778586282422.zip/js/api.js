const API = {
    async fetchFromWp(endpoint) {
        if (!CONFIG.WP_ENABLED) return null;
        try {
            const response = await fetch(`${CONFIG.WP_URL}/${CONFIG.API_NAMESPACE}/${endpoint}`);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.warn(`WP fetch failed for ${endpoint}:`, error);
            return null;
        }
    },

    async getNews() {
        const posts = await this.fetchFromWp('posts?_embed&per_page=6');
        if (!posts) return FALLBACK_DATA.news;
        
        return posts.map(post => ({
            title: post.title.rendered,
            excerpt: post.excerpt.rendered.replace(/<[^>]*>?/gm, '').substring(0, 120) + '...',
            date: new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
            category: post._embedded?.['wp:term']?.[0]?.[0]?.name || 'News',
            image: post._embedded?.['wp:featuredmedia']?.[0]?.source_url || CONFIG.IMAGES.news
        }));
    },

    async getResearch() {
        // Assuming custom post type 'research_project' exists
        const projects = await this.fetchFromWp('research_project?_embed');
        if (!projects || projects.length === 0) return FALLBACK_DATA.projects;

        return projects.map(p => ({
            title: p.title.rendered,
            category: p._embedded?.['wp:term']?.[0]?.[0]?.name || 'General',
            description: p.excerpt?.rendered.replace(/<[^>]*>?/gm, '') || '',
            image: p._embedded?.['wp:featuredmedia']?.[0]?.source_url || CONFIG.IMAGES.research1
        }));
    }
};