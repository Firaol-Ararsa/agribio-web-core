// App Initialization
document.addEventListener('DOMContentLoaded', () => {
    // Mount Static Components
    const navbar = document.getElementById('navbar');
    const footer = document.getElementById('footer');
    
    if (navbar) navbar.innerHTML = Components.Navbar();
    if (footer) footer.innerHTML = Components.Footer();
    
    // Start Router
    Router.init();

    // Initial Icon Render
    updateIcons();

    // Mobile Menu Toggle Logic
    document.addEventListener('click', (e) => {
        const menuBtn = e.target.closest('#mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (menuBtn && mobileMenu) {
            mobileMenu.classList.toggle('hidden');
        } else if (mobileMenu && !mobileMenu.classList.contains('hidden') && !e.target.closest('#mobile-menu')) {
            mobileMenu.classList.add('hidden');
        }

        // Close menu on link click
        if (e.target.closest('#mobile-menu a')) {
            mobileMenu.classList.add('hidden');
        }
    });
});

// Global navigation handler for data-route attributes
document.addEventListener('click', (e) => {
    const routeEl = e.target.closest('[data-route]');
    if (routeEl) {
        window.location.hash = routeEl.dataset.route;
    }
});