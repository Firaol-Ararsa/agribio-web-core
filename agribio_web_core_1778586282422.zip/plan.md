# Task: Update WordPress API URL

## Changes
1.  **Modify `src/config/wordpress.ts`**:
    *   Update `WORDPRESS_CONFIG.baseUrl` from `'https://nabrccom.wordpress.com'` to `'https://www.nabrc.com'`.
    *   This will automatically update `WORDPRESS_API_URL` to `'https://www.nabrc.com/wp-json/'`.

## Verification
- Run `validate_build` to ensure no syntax errors.